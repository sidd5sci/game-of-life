

food =[[1],[20],[30]]

for i,f in enumerate(food):
    food.remove(f)
    print f
